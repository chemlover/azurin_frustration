import os
import sys
import numpy as np
contactmapname = sys.argv[1]
length = int(sys.argv[2])
data=np.zeros((length,length))
np.savetxt(contactmapname,data,fmt="%.3f",delimiter=" ")
