import numpy as np
import sys
import os
import matplotlib.pyplot as plt
from matplotlib.pyplot import cm as cm
from math import *
import codecs
print "*.py pathT  xname yname pathR pciturename num_sim"
filename = sys.argv[1]
pdbid = []
rmsd1 = []
rmsd2 = []
rmsd3 = []
rmsd4 = []
rmsd5 = []
Q = []
delta = 0 
with open(filename,"r") as fopen:
     i = 0
     for line in fopen.readlines():
         pdbid.append(line.split()[0])
         rmsd1.append(float(line.split()[delta+1]))#-float(line.split()[2]))
         rmsd2.append(float(line.split()[delta+2]))# - float(line.split()[4]))
         rmsd3.append(float(line.split()[delta+3]))# - float(line.split()[1]))
         rmsd4.append(float(line.split()[delta+4]))# - float(line.split()[1]))   
         rmsd5.append(float(line.split()[delta+5]))
         Q.append(i)
         i = i + 1
plt.figure(figsize=(15,7.5))
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman'] + plt.rcParams['font.serif']
s='(\xef\xbd\xa1\xef\xbd\xa5\xcf\x89\xef\xbd\xa5\xef\xbd\xa1)\xef\xbe\x89'
s1=s.decode('utf-8')
plt.plot(Q,rmsd1,linewidth = 3.0,color = "k",marker='o',markersize=8,markeredgewidth=3,markeredgecolor="k",markerfacecolor="white") 
plt.plot(Q,rmsd2,linewidth = 3.0,color = "#00a2ff",marker='o',markersize=8,markeredgewidth=3,markeredgecolor="#00a2ff",markerfacecolor="white") 
plt.plot(Q,rmsd3,linewidth = 3.0,color = "#61d836",marker='o',markersize=8,markeredgewidth=3,markeredgecolor="#61d836",markerfacecolor="white")
plt.plot(Q,rmsd4,linewidth = 3.0,color = "#FF6A6A",marker='o',markersize=8,markeredgewidth=3,markeredgecolor="#FF6A6A",markerfacecolor="white")
plt.plot(Q,rmsd5,linewidth = 3.0,color = "orange",marker='o',markersize=8,markeredgewidth=3,markeredgecolor="orange",markerfacecolor="white")
yname = "#Minimally frustrated interaction"
plt.legend(['WT',"C112D/M121E pH 7.0","C112D/M121E pH 9.0","C112D","C112D/M121L"],loc="best",prop={'size': 12})
plt.ylabel(yname,fontsize=20)
plt.xticks(Q,pdbid,rotation='horizontal',fontsize=20)
plt.yticks(fontsize=20)
plt.tight_layout()
plt.grid(linestyle='-')
plt.savefig('./1.png',dpi=300)
plt.show()
